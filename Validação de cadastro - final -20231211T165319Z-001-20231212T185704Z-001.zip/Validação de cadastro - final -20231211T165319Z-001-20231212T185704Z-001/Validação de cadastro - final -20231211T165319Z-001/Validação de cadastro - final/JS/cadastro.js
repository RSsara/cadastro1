let listaRegistro = {
    ultimoIdGravado: 0,
    pessoas: []
};

function visualizar(pagina) {
    document.body.setAttribute('page', pagina);

    if (pagina === 'cadastro') {
        document.getElementById('nome').focus();
    }
}

function verificarSenha() {
    let senha1 = document.getElementById('tsenha').value;
    let senha2 = document.getElementById('csenha').value;

    if (senha1 !== senha2) {
        alert("As senhas não coincidem");
        return false;
    }
    return true;
}

function inserirPessoa() {
    const senhasCoincidem = verificarSenha();
    if (!senhasCoincidem) {
        return; // Se as senhas não coincidem, não prosseguir com a inserção
    }

    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const sexo = document.getElementById('sexo').value;
    const telefone = document.getElementById('telefone').value;
    const linguagens = [...document.querySelectorAll('input[name="chk_language"]:checked')].map(lang => lang.value);

    const id = listaRegistro.ultimoIdGravado + 1;
    listaRegistro.ultimoIdGravado = id; // Atualizar o último ID gravado na lista

    listaRegistro.pessoas.push({ id, nome, email, sexo, telefone, linguagens });

    desenharTabela();
    limparFormulario(); // Limpar o formulário após inserção
    visualizar('lista');
}

function desenharTabela() {
    const tbody = document.getElementById('listaRegistroBody');
    if (tbody) {
        tbody.innerHTML = listaRegistro.pessoas.map(pessoa => {
            return `<tr>
                        <td>${pessoa.id}</td>
                        <td>${pessoa.nome}</td>
                        <td>${pessoa.email}</td>
                        <td>${pessoa.sexo}</td>
                        <td>${pessoa.telefone}</td>
                        <td>${pessoa.linguagens.join(', ')}</td>
                    </tr>`;
        }).join('');
    }
}

function limparFormulario() {
    document.getElementById('nome').value = '';
    document.getElementById('email').value = '';
    document.getElementById('sexo').value = 'feminino'; // Resetar para o valor padrão
    document.getElementById('telefone').value = '';
    const checkboxes = document.querySelectorAll('input[name="chk_language"]');
    checkboxes.forEach(checkbox => checkbox.checked = false); // Desmarcar todas as checkboxes
    document.getElementById('tsenha').value = '';
    document.getElementById('csenha').value = '';
}

window.addEventListener('load', () => {
    desenharTabela();
});
